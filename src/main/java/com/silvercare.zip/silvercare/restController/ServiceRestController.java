package com.silvercare.restController;

import com.silvercare.models.CareService;
import com.silvercare.repositories.ServiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/external") // Professional API pathing
public class ServiceRestController {

    @Autowired
    private ServiceRepository serviceRepo;

    // This is the B2B endpoint for third parties
    @GetMapping("/services")
    public List<CareService> getAllServicesForPartners() {
        // This will automatically return a JSON array
        return serviceRepo.findAll();
    }
}