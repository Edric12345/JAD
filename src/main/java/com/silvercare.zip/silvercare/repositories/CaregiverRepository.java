package com.silvercare.repositories;

public class CaregiverRepository {

}
