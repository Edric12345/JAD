package com.silvercare.models;

public enum BookingStatus {
    PENDING,
    PAID,
    CANCELLED,
    CONFIRMED,
    COMPLETED
}