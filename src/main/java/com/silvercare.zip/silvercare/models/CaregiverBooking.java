package com.silvercare.models;

public class CaregiverBooking {

}
